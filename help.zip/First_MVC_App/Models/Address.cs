﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace First_MVC_App.Models
{
    public class Address
    {
        [Key]
        public int Id { get; set; }
        public string HouseNo { get; set; }
        public string Street { get; set; }
        public string PinCode { get; set; }
        public customer Customer { get; set; }
    }
}