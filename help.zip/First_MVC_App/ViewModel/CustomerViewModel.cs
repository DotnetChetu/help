﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace First_MVC_App.ViewModel
{
    public class CustomerViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Gender { get; set; }
        public string Dept { get; set; }
        public string street { get; set; }
        public string House { get; set; }
        public string PinCode { get; set; }

    }
}