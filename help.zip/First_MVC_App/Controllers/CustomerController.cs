﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using First_MVC_App.Models;
using First_MVC_App.ViewModel;

namespace First_MVC_App.Controllers
{
    public class CustomerController : Controller
    {
        // GET: Customer
        private CustomerContext context;
        public CustomerController()
        {
            context = new CustomerContext();
        }
        public ActionResult Index()
        {
            //var customers = new List<string>()
            //{
            //    "Ajay",
            //    "vijay",
            //    "sonu",
            //    "deepak"
            //};
            //ViewBag.customers = customers;
            //ViewData["customers"] = customers;
            CustomerWithDept_viewModel obj = new CustomerWithDept_viewModel();
            obj.customers = context.Customers.ToList();
            obj.departments = context.Departments.ToList();
            return View(obj);
        }

        public ActionResult Create()
        {
            ViewBag.departments = context.Departments.ToList();
            
            return View();
        }

        [HttpPost]
        //    public ActionResult Create(customer customer)
        //  public ActionResult Create(string name, string email, string mobile, string gender)
        public ActionResult Create(customer c)
        {
            //customer c = new customer();
            //c.Name=collection["name"];
            //c.Email=collection["email"];
            //c.Mobile=collection["mobile"];
            //c.Gender=collection["gender"];
            ViewBag.departments = context.Departments.ToList();

            if (c.Name==null  || c.Email == null || c.Name.Length<=5)
            {
                return View(c);
            }
            context.Customers.Add(c);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            if (context.Customers.Any(e => e.Id == id))
            {
                var cust = context.Customers.SingleOrDefault(e => e.Id == id);
                context.Customers.Remove(cust);
                context.SaveChanges();
                ViewBag.msg = "customer deleted successfully..";
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.msg = "customer not found";
                return RedirectToAction("Index");
            }
        }

        public ActionResult Edit(int id)
        {
            var cust = context.Customers.SingleOrDefault(e => e.Id == id);
            return View(cust);
        }

        [HttpPost]
        public ActionResult Update(customer customer)
        {
            context.Entry(customer).State = System.Data.Entity.EntityState.Modified;
            context.SaveChanges();
            return RedirectToAction("Index");
        }

    }
}